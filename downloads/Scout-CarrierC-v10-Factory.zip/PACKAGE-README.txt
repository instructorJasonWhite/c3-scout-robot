Scout Carrier C v10 complete factory release.
Use the matched Gerber ZIP, BOM CSV and CPL CSV together. See UPLOAD-GUIDE.html.
Current Fusion sources and previews are included. The original SHA256SUMS.txt and the additional package checksums can both be verified after extraction.
