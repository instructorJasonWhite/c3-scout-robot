Scout Rev B mechanical CAD. Main Fusion assembly, standalone chassis and populated Rev B board reference, with STEP interchange files.
This is the latest completed mechanical model. Carrier C v10 populated-component clearance has not been synchronized or physically verified.
