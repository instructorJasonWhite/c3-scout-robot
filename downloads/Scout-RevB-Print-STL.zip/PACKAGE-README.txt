Scout Rev B print set. Seven assembled parts plus optional shaft coupon.
Use the included PRINT-NOTES.txt and Fasteners-M3.csv. STL units: mm. Choose bed orientation in your slicer.
