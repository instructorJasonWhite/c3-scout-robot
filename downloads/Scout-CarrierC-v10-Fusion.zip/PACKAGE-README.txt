Scout Carrier C v10 editable electrical files: SCH, BRD, LBR, PDFs and design rules.
The RevC filenames belong to the current Carrier C release (parent/board v10, schematic v6). SCH and BRD are recovered byte-for-byte from the retained v10 copies and match the original release checksums.
